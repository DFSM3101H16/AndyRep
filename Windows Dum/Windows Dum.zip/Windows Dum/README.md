# AndyRep

+Introduction
+You are Eirik Overum.. and you are inn hell.
+Also you are late for the dance party.
+
+No one in hell likes dance parties except you and your trusty friend Satan.
+Therefore the other evildoers have decided to try to keep you from getting the party by throwing rocks at you.
+Luckily you have armed yourself with your trusty AK-47.
+Lock and load.
+Dance or DIE!
+
+Instruction
+Use your mouse to aim your gun.
+Use W to move forward.
+Use S to move backward.
+Use A to move left.
+Use D to move right.
+Use R to Reload
